<div id="footer-bar" class="footer-bar-6">
        
        <a href="#" data-menu="menu-main"><i class="fa fa-bars"></i><span>Menu</span></a>
        <a href="buy-airtime"><i class="fa fa-phone"></i><span>Airtime</span></a>
        <a href="buy-data" ><i class="fa fa-wifi"></i><span>Data</span></a>
        <a href="contact-us" >
                <img src="../../assets/images/whatsapp.png" 
                width="40" height="40" 
                style="border-radius:5rem;" />
        </a>
        
        
</div>