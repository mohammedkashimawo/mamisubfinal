<div class="mt-4"></div>
<div class="list-group list-custom-small list-menu">

    <a href="./">
        <i class="fa fa-home color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Home</span>
        <i class="fa fa-angle-right"></i>
    </a>
    <a href="fund-wallet">
        <i class="fa fa-arrow-up color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Fund Wallet</span>
        <i class="fa fa-angle-right"></i>
    </a>
    <a href="transfer">
        <i class="fa fa-arrow-down color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Wallet Transfer</span>
        <i class="fa fa-angle-right"></i>
    </a>
    
    <a href="buy-data-pin">
        <i class="fa fa-list-alt color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Data Pin</span>
        <i class="fa fa-angle-right"></i>
    </a>
    <a href="transactions">
        <i class="fa fa-receipt color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Transactions</span>
        <i class="fa fa-angle-right"></i>
    </a>

   <a href="recharge-pin">
        <i class="fa fa-print color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Recharge Pin</span>
        <i class="fa fa-angle-right"></i>
    </a>
    
    <a href="pricing">
        <i class="fa fa-list-alt color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Pricing</span>
        <i class="fa fa-angle-right"></i>
    </a>
    
    <a href="notifications">
        <i class="fa fa-list color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Notifications</span>
        <i class="fa fa-angle-right"></i>
    </a>
    
    <a href="profile">
        <i class="fa fa-user color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Profile</span>
        <i class="fa fa-angle-right"></i>
    </a>
    
    <a href="referrals">
        <i class="fa fa-users color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Referrals</span>
        <i class="fa fa-angle-right"></i>
    </a>
    <a href="logout">
        <i class="fa fa-lock color-white" style="background-color:<?php echo $sitecolor; ?>"></i>
        <span>Logout</span>
        <i class="fa fa-angle-right"></i>
    </a>
    
</div>

