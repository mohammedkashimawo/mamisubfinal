<footer class="main-footer text-center">
    <i>&copy; <?php echo date("Y"); ?> . <a href="https://welcome">2023 All Rights Reserved.</a></i>
</footer>